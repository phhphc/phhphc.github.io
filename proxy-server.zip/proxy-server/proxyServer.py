import os, threading, socket, time
import re
from datetime import datetime

# CONSTANTS
MAX_CONN = 50           # set max connections to server
MAX_BYTES = 4096        # max bytes can be receive at once

thread = []

def parse_request(request, addr):
    if not request:
        return '', ''

    first_line = request.decode("utf-8").split("\r\n")[0]    

    if "CONNECT" in first_line:
        return '', ''
    else:
        print("Connect to ", addr)
        print("Client request: ", request)

    url = first_line.split(' ')[1]

    http_pos = url.find("://")
    if (http_pos == -1):
        temp = url
    else:
        temp = url[(http_pos + 3):]
    
    port_pos = temp.find(":")

    webserver_pos = temp.find("/")
    if webserver_pos == -1:
        webserver_pos = len(temp)

    webserver = ""
    port = -1

    if (port_pos==-1 or webserver_pos < port_pos):
        port = 80
        webserver = temp[:webserver_pos]
    else:
        port = int((temp[(port_pos+1):])[:webserver_pos-port_pos-1])
        webserver = temp[:port_pos]

    return webserver, port

def proxy_thread(conn, addr, forbiden):
    request = conn.recv(MAX_BYTES)

    webserver, port = parse_request(request, addr)
    if webserver == '':
        conn.close()
        return

    port = int(port)

    if webserver in forbiden:
        # Tra ve client file forbiden403.html
        # Ngat ket noi
        print("Your connection is forbidened")
        forbidenHTMLencoded = open("forbiden.html","r").read().encode()
        timeEncode = datetime.now().strftime("%a, %d %b %Y %H:%M:%S").encode()
        response = b'HTTP/1.1 403 Forbidden\r\nDate: ' + timeEncode + b' GMT\r\n\r\n' + forbidenHTMLencoded
        conn.sendall(response)
        conn.close()
        return

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect_ex((webserver, port))
        s.settimeout(None)
        print("Redirect to: ", webserver, port)
        s.sendall(request)

        buf = b''
        res = {}
        buf_len = 0
        res_len = 0

        while 1:
            if len(buf) == 0:
                data = s.recv(MAX_BYTES)
                print(data)
                header = data.decode("ISO-8859-1").split("\r\n\r\n")[0]
                fields = header.split("\r\n")
                status = fields[0].split(' ', 1)[1]
                fields = fields[1:]
                print(status)

                print(fields)
                for field in fields:
                    if not field:
                        continue
                    key, val = field.split(':', 1)
                    res[key] = val.strip()
                
                buf += data
                buf_len += len(data)
                
                if re.findall("^2", status) and "Content-Length" in res:    # Neu la status 200
                    res_len = int(res["Content-Length"])                    
                else:
                    continue
            
            if (not data) or (buf_len < res_len):
                data = s.recv(MAX_BYTES)
                buf += data
                buf_len += len(data)
            elif (res_len==0):
                data = s.recv(MAX_BYTES)
                buf += data
                buf_len += len(data)
                if (len(data)<MAX_BYTES):
                    break
            else:
                break               

        conn.sendall(buf)

        s.close()
        conn.close()
        print("End proxy thread")
    
    except socket.timeout:
        raise OSError
    
    if s:
        s.close()
    if conn:
        conn.close()


def main():
    host = ''       # local host
    port = 8888     

    forbiden = open("blacklist.conf", "r")
    blacklist = forbiden.read().split('\n')

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, port))
        s.listen(MAX_CONN)
        s.settimeout(None)
        print("Waiting for client...")
    except socket.error:
        if s:
            s.close()
    while 1:
        conn, addr = s.accept()
        
        t = threading.Thread(target=proxy_thread, args=(conn, addr, blacklist))
        thread.append(t)
        t.start()

if __name__ == "__main__":
    main()